Prerequisite :

Java 8
Maven 3+

How to execute application

java com.rabobank.runner.MonthlyReportRunner <Arg1> <Arg2>
	Arg1 - input full file path 
	Arg2 - output folder path

java com.rabobank.runner.MonthlyReportRunner sample.xml ./out

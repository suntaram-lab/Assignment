package com.rabobank.service;

public interface ReportProcessService {
    void processReport(String filePath,String fileOutputPath);
}

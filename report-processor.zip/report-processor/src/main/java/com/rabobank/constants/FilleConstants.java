package com.rabobank.constants;

public interface FilleConstants {
    String CSV_EXTENSION = "csv";
    String XML_EXTENSION = "xml";
}

package com.rabobank.configuration;

import com.rabobank.service.ReportProcessService;
import com.rabobank.service.ReportProcessServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfiguration {

}

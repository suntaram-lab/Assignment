export interface CSVModel {
    firstName: string;
    lastName: string;
    issueCount: number;
    dateOfBirth: Date;
}
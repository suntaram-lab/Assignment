Prerequisite :

Node : v8.11.3
Npm : 6.4.1
Angular cli : 6+


How to start appication :

npm start

How to access aplication 

http://localhost:4200
